package com.example;

import java.io.InputStream;

public class MyLogWrapper {

    private static final String RESOURCE = "abc.txt";

    private MyLogWrapper(){
    }

    public static String getMessage(Exception e){

        InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(RESOURCE);
        if( inputStream == null ){
            throw new IllegalStateException("Resource file " + RESOURCE + " not found!");
        }

        /* do something with content of file and exception */
        return "someMessage";
    }

    /* some other methods... */
}
