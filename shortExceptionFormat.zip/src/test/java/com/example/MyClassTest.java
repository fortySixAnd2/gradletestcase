package com.example;

import org.junit.Test;

public class MyClassTest {

    @Test
    public void testMyMethod() throws Exception{
        new MyClass().methodToTest();
    }
}
