package com.example;


public class MyClass {

    public void methodToTest() throws Exception{
        if( (1+1) == 2 ){
            throw new MyException();
        }
    }
}
