package com.example;

public class MyException extends Exception {
    @Override
    public String getMessage(){
        String msg = MyLogWrapper.getMessage(this);

        /* do something with msg... */
        return msg;
    }
}
